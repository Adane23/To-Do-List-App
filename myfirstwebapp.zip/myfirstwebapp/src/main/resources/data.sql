insert into todo (ID, USERNAME, DESCRIPTION, TARGET_DATE, DONE)
values(1001, 'Adane', 'GET DevOps Certified', CURRENT_DATE(), false);

insert into todo (ID, USERNAME, DESCRIPTION, TARGET_DATE, DONE)
values(1002, 'Adane', 'GET Azure Certified', CURRENT_DATE(), false);

insert into todo (ID, USERNAME, DESCRIPTION, TARGET_DATE, DONE)
values(1003, 'Adane', 'GET AWS Certified', CURRENT_DATE(), false);

insert into todo (ID, USERNAME, DESCRIPTION, TARGET_DATE, DONE)
values(1004, 'Adane', 'GET Ful-Stack Certified', CURRENT_DATE(), false);